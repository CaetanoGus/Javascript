// 1 a 75, sem repetições
// B => 1 a 15
// I => 16 a 30
// N => 31 a 45
// G => 46 a 60
// O => 61 a 75

function CriarTabela()
{
    // Criando elementos principais
    const table = document.createElement("table");
    const thead = document.createElement("thead");
    const tbody = document.createElement("tbody");

    // Criando o cabeçalho
    const tr_nome = document.createElement("tr");
    const td_nome = document.createElement("td");

    // Criando os THs
    const th_B = document.createElement("th");
    th_B.innerHTML = "B";
    const th_I = document.createElement("th");
    th_I.innerHTML = "I";
    const th_N = document.createElement("th");
    th_N.innerHTML = "N";
    const th_G = document.createElement("th");
    th_G.innerHTML = "G";
    const th_O = document.createElement("th");
    th_O.innerHTML = "O";

    td_nome.innerHTML = "NOME"

    tr_nome.appendChild(tr_nome);

    // Montando a thead
    thead.appendChild(tr_nome);
    thead.appendChild(th_B);
    thead.appendChild(th_I);
    thead.appendChild(th_N);
    thead.appendChild(th_G);
    thead.appendChild(th_O);

    // Montando o tbody
    for(let i = 0; i < 5; i++)
    {
        const tr = document.createElement("tr");

        for(let j = 0; j < 5; j++)
        {
            const td = document.createElement("td")
            td.innerHTML
        }
    }

    // Montando a tabela
    table.appendChild(thead);
    table.appendChild(tbody);

    // Inserindo
    const body = document.querySelector("body");
    body.appendChild(table);
}