function ConverterTemperatura()
{
    var temperatura_celcius = prompt
    ("Digite a temperatura em Celcius: ")
    
    var temperatura_farenheit = 1.8*temperatura_celcius + 32; alert("Temperatura em Farenheit: " + temperatura_farenheit);

    var h2 = document.createElement("h2");
    h2.innerHTML = "A temperatura em Farenheit é: " + temperatura_farenheit;
    document.getElementsByTagName("body")[0].appendChild(h2);
}